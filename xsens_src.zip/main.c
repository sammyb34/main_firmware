/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

#define XBUS_BUF_LENGTH 256

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */


void flush_buf(uint8_t* buf, int len) {
	for(int i = 0; i < len; i++) {
		buf[i] = 0;
	}

	return;
}


void data_ready() {
	while(HAL_GPIO_ReadPin(DRDY_PORT, DRDY_PIN) == GPIO_PIN_RESET);
}

/*
void reset_xsens() {
	HAL_GPIO_WritePin(RST_PORT, RST_PIN, GPIO_PIN_SET);
	HAL_Delay(1000);
	HAL_GPIO_WritePin(RST_PORT, RST_PIN, GPIO_PIN_RESET);
}
*/

float bytes_to_float(uint8_t* ptr) {
	uint32_t temp = 0;

	temp |= ptr[0] << 24;
	temp |= ptr[1] << 16;
	temp |= ptr[2] << 8;
	temp |= ptr[3];

	return *((float *) &temp);
}

uint8_t reset_and_get_ack(uint8_t* tx_buf, uint8_t* rx_buf);
uint8_t goto_config_and_get_ack(uint8_t* tx_buf, uint8_t* rx_buf);
uint8_t set_output_config(uint8_t* tx_buf, uint8_t* rx_buf);
uint8_t read_data(uint8_t* tx_buf, uint8_t* rx_buf);
uint8_t goto_measurement_and_get_ack(uint8_t* tx_buf, uint8_t* rx_buf);
uint8_t stop_xsens();

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef hlpuart1;

SPI_HandleTypeDef hspi1;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_LPUART1_UART_Init(void);
static void MX_SPI1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

	uint8_t uart_tx_buf[256];
	uint8_t uart_rx_buf[256];
	uint8_t xbus_tx_buf[256];
	uint8_t	xbus_data[256];

	flush_buf(uart_tx_buf, 256);
	flush_buf(xbus_tx_buf, 256);
	flush_buf(xbus_data, 256);

	//uint16_t notification_msg_size = 0;
	//uint16_t measurement_msg_size = 0;

	//int rlen = 0;

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_LPUART1_UART_Init();
  MX_SPI1_Init();
  /* USER CODE BEGIN 2 */

  //reset_xsens();

  /*
  while (1) {
	  HAL_UART_Receive(&hlpuart1, uart_rx_buf, 256, 100);

	  HAL_UART_Transmit(&hlpuart1, uart_rx_buf, strlen((char*)uart_rx_buf), HAL_MAX_DELAY);

	  flush_buf(uart_rx_buf, 256);

  }
  */


  uint8_t version;
  uint8_t data_cfg;

  if(!cfg_protocol_xsens(&version, &data_cfg)) {
	  sprintf((char*)uart_tx_buf, "Config Failed!\r\n");
	  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);
  }

  sprintf((char*)uart_tx_buf, "Version: %x CFG: %x\r\n", version, data_cfg);
  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

  int reset_attempts = 0;

  while(!reset_xsens()) {
	  HAL_Delay(100);
	  reset_attempts++;
	  if (reset_attempts > 5) {
		  sprintf((char*)uart_tx_buf, "Reset Timeout Failed!\r\n");
		  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);
		  break;
	  }
  }

  int config_state_attempts = 0;
  while(!goto_config_xsens()) {
  	  HAL_Delay(500);
  	  config_state_attempts++;
  	  if (config_state_attempts > 5) {
  		  sprintf((char*)uart_tx_buf, "Config State Timeout Failed!\r\n");
  		  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);
  		  break;
  	  }
  }

  int config_attempts = 0;
  while(!config_xsens()) {
    	  HAL_Delay(500);
    	  config_attempts++;
    	  if (config_attempts > 5) {
    		  sprintf((char*)uart_tx_buf, "Config Timeout Failed!\r\n");
    		  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);
    		  break;
    	  }
    }

  int measurement_attempts = 0;
    while(!goto_measurement_xsens()) {
	  HAL_Delay(500);
	  measurement_attempts++;
	  if (measurement_attempts > 5) {
		  sprintf((char*)uart_tx_buf, "Measurement Timeout Failed!\r\n");
		  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);
		  break;
	  }
  }

  sprintf((char*)uart_tx_buf, "Attempts: %d\r\n", measurement_attempts);
  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

  uint16_t notificationSize;
  uint16_t measurementSize;

  data_ready_xsens(1000);

  read_pipe_status_xsens(&notificationSize, &measurementSize);

  uint8_t rx_buf[XBUS_BUF_LENGTH];

  flush_buf_xsens(rx_buf, XBUS_BUF_LENGTH);

  /*
  if(notificationSize) {
	  get_raw_from_pipe_xsens(XBUS_NOTIFICATION_PIPE, rx_buf, notificationSize);
  }

  for(int i = 0; i < notificationSize; i++) {
	  sprintf((char*)uart_tx_buf, "%x\r\n", rx_buf[i]);
	  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);
  }
  */

  float timestamp;
  float q1;
  float q2;
  float q3;
  float q4;
  float ax;
  float ay;
  float az;
  float mx;
  float my;
  float mz;

  /*

  get_packet_xsens(rx_buf, &timestamp, &q1, &q2, &q3, &q4, &ax, &ay, &az, &mx, &my, &mz);

  for(int i = 0; i < measurementSize; i++) {
	  sprintf((char*)uart_tx_buf, "%x ", rx_buf[i]);
	  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);
  }

  sprintf((char*)uart_tx_buf, "\r\n");
  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

  sprintf((char*)uart_tx_buf, "Data: %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f\r\n", timestamp, q1, q2, q3, q4, ax, ay, az, mx, my, mz);
  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

  */

  while(1) {

	  	data_ready_xsens(1000);

	  	get_packet_xsens(rx_buf, &timestamp, &q1, &q2, &q3, &q4, &ax, &ay, &az, &mx, &my, &mz);

	  	flush_buf_xsens(rx_buf, XBUS_BUF_LENGTH);

	  	/*
		for(int i = 0; i < measurementSize; i++) {
		  sprintf((char*)uart_tx_buf, "%x ", rx_buf[i]);
		  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);
		}

		sprintf((char*)uart_tx_buf, "\r\n");
		HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);
		*/

		sprintf((char*)uart_tx_buf, "Data: %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f\r\n", timestamp, q1, q2, q3, q4, ax, ay, az, mx, my, mz);
		HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);
  }


  /*
  // configure protocol
  MtsspInterface_configureProtocol(data_cfg);

  // Read Protocol configuration
  MtsspInterface_readProtocolInfo(&version, &data_cfg);

  sprintf((char*)uart_tx_buf, "Version: %x CFG: %x\r\n", version, data_cfg);
  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);
  flush_buf(xbus_data, 256);
  */

  int state = 0;


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

	  switch(state) {
		  case 0:
			  state = reset_and_get_ack(xbus_tx_buf, xbus_data);
			  break;
		  case 1:
			  state = goto_config_and_get_ack(xbus_tx_buf, xbus_data);
			  break;
		  case 2:
			  state = set_output_config(xbus_tx_buf, xbus_data);
			  break;
		  case 3:
			  state = goto_measurement_and_get_ack(xbus_tx_buf, xbus_data);
			  break;
		  case 4:
			  state = read_data(xbus_tx_buf, xbus_data);
			  break;
		  case 5:
			  state = stop_xsens();
			  break;
	  }


    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_9;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
  RCC_OscInitStruct.PLL.PLLM = 5;
  RCC_OscInitStruct.PLL.PLLN = 71;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV6;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV4;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief LPUART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_LPUART1_UART_Init(void)
{

  /* USER CODE BEGIN LPUART1_Init 0 */

  /* USER CODE END LPUART1_Init 0 */

  /* USER CODE BEGIN LPUART1_Init 1 */

  /* USER CODE END LPUART1_Init 1 */
  hlpuart1.Instance = LPUART1;
  hlpuart1.Init.BaudRate = 115200;
  hlpuart1.Init.WordLength = UART_WORDLENGTH_8B;
  hlpuart1.Init.StopBits = UART_STOPBITS_1;
  hlpuart1.Init.Parity = UART_PARITY_NONE;
  hlpuart1.Init.Mode = UART_MODE_TX_RX;
  hlpuart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  hlpuart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  hlpuart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&hlpuart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN LPUART1_Init 2 */

  /* USER CODE END LPUART1_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_HIGH;
  hspi1.Init.CLKPhase = SPI_PHASE_2EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 7;
  hspi1.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
  hspi1.Init.NSSPMode = SPI_NSS_PULSE_DISABLE;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOG_CLK_ENABLE();
  HAL_PWREx_EnableVddIO2();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOF, GPIO_PIN_14, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LD3_Pin|LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOG, USB_PowerSwitchOn_Pin|SMPS_V1_Pin|SMPS_EN_Pin|SMPS_SW_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : USER_BUTTON_Pin */
  GPIO_InitStruct.Pin = USER_BUTTON_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(USER_BUTTON_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PF14 */
  GPIO_InitStruct.Pin = GPIO_PIN_14;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

  /*Configure GPIO pin : DRDY_Pin */
  GPIO_InitStruct.Pin = DRDY_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(DRDY_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LD3_Pin LD2_Pin */
  GPIO_InitStruct.Pin = LD3_Pin|LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PD14 */
  GPIO_InitStruct.Pin = GPIO_PIN_14;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : USB_OverCurrent_Pin SMPS_PG_Pin */
  GPIO_InitStruct.Pin = USB_OverCurrent_Pin|SMPS_PG_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

  /*Configure GPIO pins : USB_PowerSwitchOn_Pin SMPS_V1_Pin SMPS_EN_Pin SMPS_SW_Pin */
  GPIO_InitStruct.Pin = USB_PowerSwitchOn_Pin|SMPS_V1_Pin|SMPS_EN_Pin|SMPS_SW_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

  /*Configure GPIO pins : USB_SOF_Pin USB_ID_Pin USB_DM_Pin USB_DP_Pin */
  GPIO_InitStruct.Pin = USB_SOF_Pin|USB_ID_Pin|USB_DM_Pin|USB_DP_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF10_OTG_FS;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

uint8_t reset_and_get_ack(uint8_t* tx_buf, uint8_t* rx_buf) {

	uint8_t uart_tx_buf[256];

	uint16_t notification_msg_size = 0;
	uint16_t measurement_msg_size = 0;

	data_ready();

	Xbus_message(tx_buf, XBUS_MASTERDEVICE, XMID_Reset, 0);
	Xbus_insertChecksum(tx_buf);
	MtsspInterface_sendXbusMessage(tx_buf);

	flush_buf(tx_buf, 256);

	data_ready();

	// Read Pipe Status
	MtsspInterface_readPipeStatus(&notification_msg_size, &measurement_msg_size);

	// Print Pipe Status
	//sprintf((char*)uart_tx_buf, "N: 0x%x M: 0x%x\r\n", notification_msg_size, measurement_msg_size);
	//HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	if (notification_msg_size && (notification_msg_size < XBUS_BUF_LENGTH)) {
	  MtsspInterface_readFromPipe(rx_buf, notification_msg_size, XBUS_NOTIFICATION_PIPE);
	}

	if(Red_Xbus_getMessageId(rx_buf) == XMID_ResetAck) {
	  sprintf((char*)uart_tx_buf, "Device Reset\r\n");
	  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	  return 1;
	}

	if(Red_Xbus_getMessageId(rx_buf) == XMID_Error) {
	  sprintf((char*)uart_tx_buf, "***Error:\r\n");
	  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	  for(int i = 0; i < Red_Xbus_getRawLength(rx_buf); i++) {
		  sprintf((char*)uart_tx_buf, "0x%x\r\n", rx_buf[i]);
		  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);
	  }

	  sprintf((char*)uart_tx_buf, "/Error\r\n");
	  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	  return 0;
	}

	return 0;
}

uint8_t goto_config_and_get_ack(uint8_t* tx_buf, uint8_t* rx_buf) {

	uint8_t uart_tx_buf[256];

	uint16_t notification_msg_size = 0;
	uint16_t measurement_msg_size = 0;

	data_ready();

	Xbus_message(tx_buf, XBUS_MASTERDEVICE, XMID_GotoConfig, 0);
	Xbus_insertChecksum(tx_buf);
	MtsspInterface_sendXbusMessage(tx_buf);

	flush_buf(tx_buf, 256);

	data_ready();

	// Read Pipe Status
	MtsspInterface_readPipeStatus(&notification_msg_size, &measurement_msg_size);

	// Print Pipe Status
	//sprintf((char*)uart_tx_buf, "N: 0x%x M: 0x%x\r\n", notification_msg_size, measurement_msg_size);
	//HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	if (notification_msg_size && (notification_msg_size < XBUS_BUF_LENGTH)) {
	  MtsspInterface_readFromPipe(rx_buf, notification_msg_size, XBUS_NOTIFICATION_PIPE);
	}

	if(Red_Xbus_getMessageId(rx_buf) == XMID_GotoConfigAck) {
	  sprintf((char*)uart_tx_buf, "Config Mode\r\n");
	  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	  return 2;
	}

	if(Red_Xbus_getMessageId(rx_buf) == XMID_Error) {
	  sprintf((char*)uart_tx_buf, "***Error:\r\n");
	  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	  for(int i = 0; i < Red_Xbus_getRawLength(rx_buf); i++) {
		  sprintf((char*)uart_tx_buf, "0x%x\r\n", rx_buf[i]);
		  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);
	  }

	  sprintf((char*)uart_tx_buf, "/Error\r\n");
	  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	  return 1;
	}

	return 1;
}

uint8_t set_output_config(uint8_t* tx_buf, uint8_t* rx_buf) {

	uint8_t uart_tx_buf[256];

	uint16_t notification_msg_size = 0;
	uint16_t measurement_msg_size = 0;

	data_ready();

	Xbus_message(tx_buf, XBUS_MASTERDEVICE, XMID_SetOutputConfig, 12);
	uint8_t* payload = Xbus_getPointerToPayload(tx_buf);
	payload[0] = 0x20; // Set up orientation data output in Quaternions
	payload[1] = 0x10;
	payload[2] = 0x00;
	payload[3] = 0x32; // 50Hz in hexadecimal
	payload[4] = 0x40; // Set up acceleration data output (m/s^2)
	payload[5] = 0x20;
	payload[6] = 0x00;
	payload[7] = 0x32; // Again, 50Hz
	payload[8] = 0xC0;
	payload[9] = 0x20;
	payload[10] = 0x00;
	payload[11] = 0x32;
	Xbus_insertChecksum(tx_buf);
	MtsspInterface_sendXbusMessage(tx_buf);

	flush_buf(tx_buf, 256);

	data_ready();

	// Read Pipe Status
	MtsspInterface_readPipeStatus(&notification_msg_size, &measurement_msg_size);

	// Print Pipe Status
	//sprintf((char*)uart_tx_buf, "N: 0x%x M: 0x%x\r\n", notification_msg_size, measurement_msg_size);
	//HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	if (notification_msg_size && (notification_msg_size < XBUS_BUF_LENGTH)) {
	  MtsspInterface_readFromPipe(rx_buf, notification_msg_size, XBUS_NOTIFICATION_PIPE);
	}

	if(Red_Xbus_getMessageId(rx_buf) == XMID_OutputConfig) {
	  sprintf((char*)uart_tx_buf, "Configured\r\n");
	  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	  return 3;
	}

	if(Red_Xbus_getMessageId(rx_buf) == XMID_Error) {
	  sprintf((char*)uart_tx_buf, "***Error:\r\n");
	  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	  for(int i = 0; i < Red_Xbus_getRawLength(rx_buf); i++) {
		  sprintf((char*)uart_tx_buf, "0x%x\r\n", rx_buf[i]);
		  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);
	  }

	  sprintf((char*)uart_tx_buf, "/Error\r\n");
	  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	  return 2;
	}

	return 2;
}

uint8_t goto_measurement_and_get_ack(uint8_t* tx_buf, uint8_t* rx_buf) {

	uint8_t uart_tx_buf[256];

	uint16_t notification_msg_size = 0;
	uint16_t measurement_msg_size = 0;

	data_ready();

	Xbus_message(tx_buf, XBUS_MASTERDEVICE, XMID_GotoMeasurement, 0);
	Xbus_insertChecksum(tx_buf);
	MtsspInterface_sendXbusMessage(tx_buf);

	flush_buf(tx_buf, 256);

	data_ready();

	// Read Pipe Status
	MtsspInterface_readPipeStatus(&notification_msg_size, &measurement_msg_size);

	// Print Pipe Status
	//sprintf((char*)uart_tx_buf, "N: 0x%x M: 0x%x\r\n", notification_msg_size, measurement_msg_size);
	//HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	if (notification_msg_size && (notification_msg_size < XBUS_BUF_LENGTH)) {
	  MtsspInterface_readFromPipe(rx_buf, notification_msg_size, XBUS_NOTIFICATION_PIPE);
	}

	if(Red_Xbus_getMessageId(rx_buf) == XMID_GotoMeasurementAck) {
	  sprintf((char*)uart_tx_buf, "Measurement Mode\r\n");
	  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	  return 4;
	}

	if(Red_Xbus_getMessageId(rx_buf) == XMID_Error) {
	  sprintf((char*)uart_tx_buf, "***Error:\r\n");
	  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	  for(int i = 0; i < Red_Xbus_getRawLength(rx_buf); i++) {
		  sprintf((char*)uart_tx_buf, "0x%x\r\n", rx_buf[i]);
		  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);
	  }

	  sprintf((char*)uart_tx_buf, "/Error\r\n");
	  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	  return 3;
	}

	return 3;
}

uint8_t read_data(uint8_t* tx_buf, uint8_t* rx_buf) {

	uint8_t uart_tx_buf[256];

	uint16_t notification_msg_size = 0;
	uint16_t measurement_msg_size = 0;

	float q1;
	float q2;
	float q3;
	float q4;

	float ax;
	float ay;
	float az;

	float mx;
	float my;
	float mz;

	float hdg;

	if(HAL_GPIO_ReadPin(USER_BUTTON_GPIO_Port, USER_BUTTON_Pin) == GPIO_PIN_SET) {
		return 5;
	}

	//data_ready();

	//Xbus_message(tx_buf, XBUS_MASTERDEVICE, XMID_SetOutputConfig, 4);
	//uint8_t* payload = Xbus_getPointerToPayload(tx_buf);

	flush_buf(tx_buf, 256);

	data_ready();

	// Read Pipe Status
	MtsspInterface_readPipeStatus(&notification_msg_size, &measurement_msg_size);

	// Print Pipe Status
	sprintf((char*)uart_tx_buf, "N: 0x%x M: 0x%x\r\n", notification_msg_size, measurement_msg_size);
	HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	if (measurement_msg_size && (measurement_msg_size < XBUS_BUF_LENGTH)) {
	  MtsspInterface_readFromPipe(rx_buf, notification_msg_size, XBUS_NOTIFICATION_PIPE);
	}

	sprintf((char*)uart_tx_buf, "0x%x 0x%x 0x%x 0x%x\r\n", rx_buf[0], rx_buf[1], rx_buf[2], rx_buf[3]);
	HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	if (measurement_msg_size && (measurement_msg_size < XBUS_BUF_LENGTH)) {
	  MtsspInterface_readFromPipe(rx_buf, measurement_msg_size, XBUS_MEASUREMENT_PIPE);
	}

	if(Red_Xbus_getMessageId(rx_buf) == XMID_MtData2) {
	  //sprintf((char*)uart_tx_buf, "Received Data!\r\n");
	  //HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	  q1 = bytes_to_float(Red_Xbus_getPointerToPayload(rx_buf) + 3);
	  q2 = bytes_to_float(Red_Xbus_getPointerToPayload(rx_buf) + 3 + (4));
	  q3 = bytes_to_float(Red_Xbus_getPointerToPayload(rx_buf) + 3 + (2*4));
	  q4 = bytes_to_float(Red_Xbus_getPointerToPayload(rx_buf) + 3 + (3*4));

	  ax = bytes_to_float(Red_Xbus_getPointerToPayload(rx_buf) + 3 + 16 + 3);
	  ay = bytes_to_float(Red_Xbus_getPointerToPayload(rx_buf) + 3 + 16 + 3 + (4));
	  az = bytes_to_float(Red_Xbus_getPointerToPayload(rx_buf) + 3 + 16 + 3 + (4*2));

	  mx = bytes_to_float(Red_Xbus_getPointerToPayload(rx_buf) + 3 + 16 + 3 + 12 + 3);
	  my = bytes_to_float(Red_Xbus_getPointerToPayload(rx_buf) + 3 + 16 + 3 + 12 + 3 + (4));
	  mz = bytes_to_float(Red_Xbus_getPointerToPayload(rx_buf) + 3 + 16 + 3 + 12 + 3 + (4*2));

	  hdg = (float) (-1 * atan2(mx, my) * 180 / M_PI);

	  if(hdg < 0) {
		  hdg += 360;
	  }

	  // PRINT EVERYTHING
	  sprintf((char*)uart_tx_buf, "Data: %f, %f, %f, %f, %f, %f, %f, %f, %f, %f\r\n", q1, q2, q3, q4, ax, ay, az, mx, my, mz);
	  HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	  // PRINT QUATERNIONS ONLY
	  // sprintf((char*)uart_tx_buf, "Quaternion: %f, %f, %f, %f\r\n", q1, q2, q3, q4);
	  //HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	  // PRINT ACCELERATION ONLY
	  //sprintf((char*)uart_tx_buf, "Acceleration (x, y, z): %f, %f, %f\r\n", ax, ay, az);
	  //HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	  // PRINT MAG ONLY
	  //sprintf((char*)uart_tx_buf, "Magnetometer + calculated heading: %f, %f, %f, %f\r\n", mx, my, mz, hdg);
	  //HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

		/*
		for (uint8_t i = 0; i < Red_Xbus_getRawLength(rx_buf); i++) {
			sprintf((char*)uart_tx_buf, "%x ", rx_buf[i]);
			HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);
		}
		sprintf((char*)uart_tx_buf, "\r\n");
		HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);
		*/

		  return 4;
		}

	return 4;
}

uint8_t stop_xsens() {
	HAL_Delay(500);

	uint8_t uart_tx_buf[256];

	sprintf((char*)uart_tx_buf, "Stopping Measurement, Press blue button to restart\r\n");
	HAL_UART_Transmit(&hlpuart1, uart_tx_buf, strlen((char*)uart_tx_buf), HAL_MAX_DELAY);

	while(1) {
		if(HAL_GPIO_ReadPin(USER_BUTTON_GPIO_Port, USER_BUTTON_Pin) == GPIO_PIN_SET) {
			return 0;
		}
	}
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

