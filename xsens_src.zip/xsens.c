/*
 * xsens.c
 *
 *  Created on: Apr 29, 2022
 *      Author: grays
 */
#include "xsens.h"
#include "stm32l4xx_hal.h"
#include "board.h"
#include "mtssp_interface.h"
#include "xbus.h"
#include "xbus_reduced.h"
#include "mtssp_driver_spi.h"
#include "xbusmessageid.h"

#define XBUS_BUF_LENGTH 256

void power_on_xsens() {
	//HAL_GPIO_WritePin();
}
void power_off_xsens() {
	//HAL_GPIO_WritePin();
}

void flush_buf_xsens(uint8_t* buf, int len) {
	for(int i = 0; i < len; i++) {
		buf[i] = 0;
	}

	return;
}

int cfg_protocol_xsens(uint8_t* version, uint8_t* data_cfg_test) {

	  uint8_t data_cfg = 0b00001100;

	  MtsspInterface_configureProtocol(data_cfg);
	  MtsspInterface_readProtocolInfo(version, data_cfg_test);

	  if(*data_cfg_test != data_cfg) {
		  return 0;
	  }
	  else {
		  return 1;
	  }

	  return 0;
}


// waits for the data ready pin to go high
// 200ms timeout, returns 0 on timeout
int data_ready_xsens(int timeout) {
	int initial_time = HAL_GetTick();
	int current_time;
	while(HAL_GPIO_ReadPin(DRDY_PORT, DRDY_PIN) == GPIO_PIN_RESET) {
		current_time = HAL_GetTick();
		if(current_time - initial_time > timeout) {
			return 0;
		}
	}
	return 1;
}


int reset_xsens() {

		uint8_t tx_buf[XBUS_BUF_LENGTH];
		uint8_t rx_buf[XBUS_BUF_LENGTH];

		uint16_t notification_msg_size = 0;
		uint16_t measurement_msg_size = 0;

		data_ready_xsens(2000);

		Xbus_message(tx_buf, XBUS_MASTERDEVICE, XMID_Reset, 0);
		Xbus_insertChecksum(tx_buf);
		MtsspInterface_sendXbusMessage(tx_buf);

		flush_buf_xsens(tx_buf, 256);

		data_ready_xsens(2000);

		// Read Pipe Status
		MtsspInterface_readPipeStatus(&notification_msg_size, &measurement_msg_size);

		if (notification_msg_size && (notification_msg_size < XBUS_BUF_LENGTH)) {
		  MtsspInterface_readFromPipe(rx_buf, notification_msg_size, XBUS_NOTIFICATION_PIPE);
		}

		if(Red_Xbus_getMessageId(rx_buf) == XMID_ResetAck) {
		  return 1;
		}

		if(Red_Xbus_getMessageId(rx_buf) == XMID_Error) {
		  return 0;
		}

		return 0;
}

int goto_config_xsens() {

		uint8_t tx_buf[XBUS_BUF_LENGTH];
		uint8_t rx_buf[XBUS_BUF_LENGTH];

		uint16_t notification_msg_size = 0;
		uint16_t measurement_msg_size = 0;

		int xsens_state = 0; // 0 is the intro state (unknown), 1 is config state


		if(!data_ready_xsens(500)) {
			return 0;
		}

		Xbus_message(tx_buf, XBUS_MASTERDEVICE, XMID_GotoConfig, 0);
		Xbus_insertChecksum(tx_buf);
		MtsspInterface_sendXbusMessage(tx_buf);

		flush_buf_xsens(tx_buf, 256);

		if(!data_ready_xsens(500)) {
			return 0;
		}

		// Read Pipe Status
		MtsspInterface_readPipeStatus(&notification_msg_size, &measurement_msg_size);

		if (notification_msg_size && (notification_msg_size < XBUS_BUF_LENGTH)) {
		  MtsspInterface_readFromPipe(rx_buf, notification_msg_size, XBUS_NOTIFICATION_PIPE);
		}

		if(Red_Xbus_getMessageId(rx_buf) == XMID_GotoConfigAck) {
		  return 1;
		}

		if(Red_Xbus_getMessageId(rx_buf) == XMID_Error) {
		  return 0;
		}

		return xsens_state; // for debug only
}

int config_xsens() {

		uint8_t tx_buf[XBUS_BUF_LENGTH];
		uint8_t rx_buf[XBUS_BUF_LENGTH];

		uint16_t notification_msg_size = 0;
		uint16_t measurement_msg_size = 0;

		if(!data_ready_xsens(500)) {
			return 0;
		}

		Xbus_message(tx_buf, XBUS_MASTERDEVICE, XMID_SetOutputConfig, 16);
		uint8_t* payload = Xbus_getPointerToPayload(tx_buf);

		payload[0] = 0x10;
		payload[1] = 0x60;
		payload[2] = 0xFF; // Timestamp will accompany every message
		payload[3] = 0xFF;
		payload[4] = 0x20; // Set up orientation data output in Quaternions
		payload[5] = 0x10;
		payload[6] = 0x00;
		payload[7] = 0x0A; // 10Hz in hexadecimal
		payload[8] = 0x40; // Set up acceleration data output (m/s^2)
		payload[9] = 0x20;
		payload[10] = 0x00;
		payload[11] = 0x0A; // 10Hz
		payload[12] = 0xC0; // Magnetometer
		payload[13] = 0x20;
		payload[14] = 0x00;
		payload[15] = 0x0A; // 10Hz
		/*
		payload[0] = 0x20; // Set up orientation data output in Quaternions
		payload[1] = 0x10;
		payload[2] = 0x00;
		payload[3] = 0x32; // 50Hz in hexadecimal
		payload[4] = 0x40; // Set up acceleration data output (m/s^2)
		payload[5] = 0x20;
		payload[6] = 0x00;
		payload[7] = 0x32; // Again, 50Hz
		payload[8] = 0xC0;
		payload[9] = 0x20;
		payload[10] = 0x00;
		payload[11] = 0x32;
		*/

		Xbus_insertChecksum(tx_buf);
		MtsspInterface_sendXbusMessage(tx_buf);

		flush_buf_xsens(tx_buf, 256);

		if(!data_ready_xsens(500)) {
			return 0;
		}

		// Read Pipe Status
		MtsspInterface_readPipeStatus(&notification_msg_size, &measurement_msg_size);

		if (notification_msg_size && (notification_msg_size < XBUS_BUF_LENGTH)) {
		  MtsspInterface_readFromPipe(rx_buf, notification_msg_size, XBUS_NOTIFICATION_PIPE);
		}

		if(Red_Xbus_getMessageId(rx_buf) == XMID_OutputConfig) {

			Xbus_message(tx_buf, XBUS_MASTERDEVICE, XMID_SetBaudrate, 1);
			uint8_t* payload = Xbus_getPointerToPayload(tx_buf);
			payload[0] = 0x0C;
			Xbus_insertChecksum(tx_buf);
			MtsspInterface_sendXbusMessage(tx_buf);

			flush_buf_xsens(tx_buf, 256);


		  return 1;
		}

		if(Red_Xbus_getMessageId(rx_buf) == XMID_Error) {
		  return 0;
		}

		return 0;

}

int goto_measurement_xsens() {

	uint8_t tx_buf[XBUS_BUF_LENGTH];
	uint8_t rx_buf[XBUS_BUF_LENGTH];

	uint16_t notification_msg_size = 0;
	uint16_t measurement_msg_size = 0;

	if(!data_ready_xsens(500)) {
		return 0;
	}

	Xbus_message(tx_buf, XBUS_MASTERDEVICE, XMID_GotoMeasurement, 0);
	Xbus_insertChecksum(tx_buf);
	MtsspInterface_sendXbusMessage(tx_buf);

	flush_buf_xsens(tx_buf, 256);

	if(!data_ready_xsens(500)) {
		return 0;
	}

	// Read Pipe Status
	MtsspInterface_readPipeStatus(&notification_msg_size, &measurement_msg_size);

	if (notification_msg_size && (notification_msg_size < XBUS_BUF_LENGTH)) {
	  MtsspInterface_readFromPipe(rx_buf, notification_msg_size, XBUS_NOTIFICATION_PIPE);
	}

	if(Red_Xbus_getMessageId(rx_buf) == XMID_GotoMeasurementAck) {
	  return 1;
	}

	if(Red_Xbus_getMessageId(rx_buf) == XMID_Error) {
	  return 0;
	}

	return 0;

}

uint32_t bytes_2_int(uint8_t* ptr) {

	uint32_t temp = 0;

		temp |= ptr[0] << 24;
		temp |= ptr[1] << 16;
		temp |= ptr[2] << 8;
		temp |= ptr[3];

	return temp;

}

float bytes_2_float(uint8_t* ptr) {
	uint32_t temp = 0;

		temp |= ptr[0] << 24;
		temp |= ptr[1] << 16;
		temp |= ptr[2] << 8;
		temp |= ptr[3];

	return *((float *) &temp);
}

void read_pipe_status_xsens(uint16_t* notificationMessageSize, uint16_t* measurementMessageSize) {
	MtsspInterface_readPipeStatus(notificationMessageSize, measurementMessageSize);
}

void get_packet_xsens(uint8_t* rx_buf, float* timestamp, float* q1, float* q2, float* q3, float* q4, float* ax, float* ay, float* az, float* mx, float* my, float* mz) {

	uint16_t notificationSize;
    uint16_t measurementSize;

    MtsspInterface_readPipeStatus(&notificationSize, &measurementSize);

    if (measurementSize && (measurementSize < XBUS_BUF_LENGTH)) {
		MtsspInterface_readFromPipe(rx_buf, measurementSize, XBUS_MEASUREMENT_PIPE);
	}

    if(Red_Xbus_getMessageId(rx_buf) == XMID_MtData2) {
    	uint8_t* payload = Red_Xbus_getPointerToPayload(rx_buf);

    	*timestamp = ((float) bytes_2_int(payload + 3))*0.0001;
    	payload = payload + 3 + 3 + 4;

    	*q1 = bytes_2_float(payload);
    	payload = payload + 4;
    	*q2 = bytes_2_float(payload);
		payload = payload + 4;
		*q3 = bytes_2_float(payload);
		payload = payload + 4;
		*q4 = bytes_2_float(payload);
		payload = payload + 4 + 3;

		*ax = bytes_2_float(payload);
		payload = payload + 4;
		*ay = bytes_2_float(payload);
		payload = payload + 4;
		*az = bytes_2_float(payload);
		payload = payload + 4 + 3;

		*mx = bytes_2_float(payload);
		payload = payload + 4;
		*my = bytes_2_float(payload);
		payload = payload + 4;
		*mz = bytes_2_float(payload);
		payload = payload + 4 + 3;

    }

}

void get_raw_from_pipe_xsens(uint8_t pipe, uint8_t* bytearray, int len) {

	MtsspInterface_readFromPipe(bytearray, len, pipe);
}
