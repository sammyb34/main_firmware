/*
 * xsens.h
 *
 *  Created on: Apr 29, 2022
 *      Author: grays
 */

#ifndef INC_XSENS_H_
#define INC_XSENS_H_

#include <stdint.h>

void power_on_xsens();
void power_off_xsens();

void flush_buf_xsens(uint8_t* buf, int len);
// Configure protocol, should be called before reset_xsens();
int cfg_protocol_xsens();

// Wait for data ready pin to go high with a configurable timeout;
int data_ready_xsens(int timeout);

// Reset the xsens
int reset_xsens();

// put the xsens in configuration mode
int goto_config_xsens();

// Configure output mode of xsens. the xsens MUST be in configuration mode for this to work!!
int config_xsens();

int goto_measurement_xsens();


uint32_t bytes_2_int(uint8_t* pointer);

float bytes_2_float(uint8_t* pointer);


void read_pipe_status_xsens(uint16_t* notificationMessageSize, uint16_t* measurementMessageSize);

void get_packet_xsens(uint8_t* rx_buf, float* timestamp, float* q1, float* q2, float* q3, float* q4, float* ax, float* ay, float* az, float* mx, float* my, float* mz);

void get_raw_from_pipe_xsens(uint8_t pipe, uint8_t* bytearray, int len);



#endif /* INC_XSENS_H_ */
