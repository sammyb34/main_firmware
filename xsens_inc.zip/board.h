/*
 * board.h
 *
 *  Created on: Nov 28, 2021
 *      Author: Grayson
 */

#ifndef INC_BOARD_H_
#define INC_BOARD_H_

#include "stm32l4xx_hal.h"

#define CHIP_SELECT_PORT 	GPIOD
#define CHIP_SELECT_PIN		GPIO_PIN_14

#define DRDY_PORT 	GPIOE
#define DRDY_PIN	GPIO_PIN_13

#define RST_PORT	GPIOF
#define RST_PIN		GPIO_PIN_14

#endif /* INC_BOARD_H_ */
